#!/bin/bash
python3 collect.py
python3 generate_plot.py
# Set the root directory
root_directory=$(pwd)

# Set the name of the zip file to be created
output_zip="Collected_Files.zip"

# Collect Output_*.txt from subdirectories
find "$root_directory" -type f -name "Output_*.txt" > tmp_file_list.txt

# Collect results_*.txt only from root directory (not subdirs)
find "$root_directory" -maxdepth 1 -type f -name "results_*.txt" >> tmp_file_list.txt

# Collect *.png only from root directory (not subdirs)
find "$root_directory" -maxdepth 1 -type f -name "*.png" >> tmp_file_list.txt

# Create zip archive
if [[ -s tmp_file_list.txt ]]; then
    zip "$output_zip" -@ < tmp_file_list.txt
    echo "✅ Collected files have been zipped into $output_zip"
else
    echo "⚠️ No matching files found."
fi

# Clean up
rm -f tmp_file_list.txt

