import re
import os
import matplotlib.pyplot as plt
import json

# ======================
# 1. Parse total averages
# ======================
def parse_results(file_path, algo_name):
    with open(file_path, "r") as f:
        content = f.read()

    pattern = r"=== Results for (Output_[^\n]+)\s+===\n(.*?)(?:\n=+|\Z)"
    matches = re.findall(pattern, content, re.S)

    results = []
    for header, body in matches:
        m = re.match(
            r"Output_[A-Za-z]+_(\d+)_(\d+)_(\d+(?:\.\d+)?)_(\d+)_(\d+(?:\.\d+))\.txt",
            header.strip()
        )
        if not m:
            continue

        dataset, density, overhead, cores, interval = m.groups()
        dataset = int(dataset)
        density = int(density)
        overhead = float(overhead)
        cores = int(cores)
        interval = float(interval)

        # Find total avg line
        m2 = re.search(r"Total Avg Score:\s*([\d.]+),\s*Total Avg Time:\s*([\d.]+)", body)
        if not m2:
            continue
        score, time = map(float, m2.groups())

        results.append({
            "algo": algo_name,
            "dataset": dataset,
            "density": density,
            "overhead": overhead,
            "cores": cores,
            "interval": interval,
            "score": score,
            "time": time,
        })
    return results


# ======================
# 2. Parse bucket-wise results
# ======================
def parse_buckets(file_path, header_key):
    with open(file_path,"r") as f:
        content = f.read()
    pattern = r"=== Results for " + re.escape(header_key) + r".*?===\n(.*?)Total Avg"
    m = re.search(pattern, content, re.S)
    buckets = {}
    if not m:
        return buckets
    section = m.group(1)
    for line in section.splitlines():
        if line.startswith("("):
            parts = line.split()
            rng, score, time = parts[0], float(parts[1]), float(parts[2])
            buckets[rng] = (score, time)
    return buckets


# ======================
# 3. Load algorithms
# ======================
file_i = "results_iSCOPE.txt"
file_b = "results_BiSCOPE.txt"
file_a = "results_Astar.txt"

iSCOPE = parse_results(file_i, "iSCOPE")
BiSCOPE = parse_results(file_b, "BiSCOPE")
Astar = parse_results(file_a, "TD-A*")
all_results = iSCOPE + BiSCOPE + Astar

header_i = "Output_iSCOPE_264346_20_30.0_1_360.0.txt"
header_b = "Output_BiSCOPE_264346_20_30.0_1_360.0.txt"
header_a = "Output_Astar_264346_20_30.0_1_360.0.txt"

b_i = parse_buckets(file_i, header_i)
b_b = parse_buckets(file_b, header_b)
b_a = parse_buckets(file_a, header_a)

buckets = {"iSCOPE": b_i, "BiSCOPE": b_b, "TD-A*": b_a}


# ======================
# 4. Generate second script
# ======================
out_script = "plot_static.py"

template = f"""
import matplotlib.pyplot as plt
import os

# Hardcoded experimental results
all_results = {json.dumps(all_results, indent=4)}

buckets = {json.dumps(buckets, indent=4)}

markers = {{"iSCOPE": "o", "BiSCOPE": "s", "TD-A*": "^"}}
defaults = {{"dataset": 264346, "density": 20, "overhead": 30.0, "cores": 24, "interval": 360.0}}

def sorted_unique(vals):
    return sorted(set(vals), key=lambda x: float(x))

def plot_var(var, all_results, defaults, out_dir):
    def matches_defaults(r):
        for k,v in defaults.items():
            if k == var:
                continue
            if r[k] != v:
                return False
        return True

    xs = sorted_unique([r[var] for r in all_results if matches_defaults(r)])
    positions = range(len(xs))
    algos = sorted(set(r["algo"] for r in all_results))

    plt.figure(figsize=(7,5))
    for algo in algos:
        ys = []
        for val in xs:
            rec = next((r for r in all_results if r["algo"]==algo and r[var]==val and matches_defaults(r)), None)
            ys.append(rec["score"] if rec else float('nan'))
        plt.plot(positions, ys, marker=markers.get(algo, 'o'),
                 markersize=12, markerfacecolor="none", label=algo)
    plt.xticks(positions, [str(x) for x in xs])
    plt.xlabel(var, fontsize=20)
    plt.ylabel("average score", fontsize=20)
    plt.tick_params(axis='x', labelsize=18)
    plt.tick_params(axis='y', labelsize=18)
    plt.legend(fontsize=18)
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, f"compare_{{var}}_score.pdf"))
    plt.close()

    plt.figure(figsize=(7,5))
    for algo in algos:
        ys = []
        for val in xs:
            rec = next((r for r in all_results if r["algo"]==algo and r[var]==val and matches_defaults(r)), None)
            ys.append(rec["time"] if rec else float('nan'))
        plt.plot(positions, ys, marker=markers.get(algo, 'o'),
                 markersize=12, markerfacecolor="none", label=algo)
    plt.xticks(positions, [str(x) for x in xs])
    plt.xlabel(var, fontsize=20)
    plt.ylabel("average runtime\\n(in seconds)", fontsize=20)
    plt.tick_params(axis='x', labelsize=18)
    plt.tick_params(axis='y', labelsize=18)
    plt.legend(fontsize=18)
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, f"compare_{{var}}_time.pdf"))
    plt.close()


out_dir = os.getcwd()
for var in ["overhead", "density", "cores", "interval", "dataset"]:
    plot_var(var, all_results, defaults, out_dir)

labels = list(next(iter(buckets.values())).keys())
x = range(len(labels))

plt.figure(figsize=(8,5))
for algo, vals in buckets.items():
    scores = [vals[k][0] for k in labels]
    plt.plot(x, scores, marker=markers.get(algo,'o'),
             markersize=12, markerfacecolor="none", label=algo)
plt.xticks(x, labels)
plt.xlabel("fastest path range in minutes", fontsize=20)
plt.ylabel("average score", fontsize=20)
plt.tick_params(axis='x', labelsize=18)
plt.tick_params(axis='y', labelsize=18)
plt.legend(fontsize=18)
plt.tight_layout()
plt.savefig(os.path.join(out_dir, "bucket_score.pdf"))
plt.close()

plt.figure(figsize=(8,5))
for algo, vals in buckets.items():
    times = [vals[k][1] for k in labels]
    plt.plot(x, times, marker=markers.get(algo,'o'),
             markersize=12, markerfacecolor="none", label=algo)
plt.xticks(x, labels)
plt.xlabel("fastest path range in minutes", fontsize=20)
plt.ylabel("average runtime\\n(in seconds)", fontsize=20)
plt.tick_params(axis='x', labelsize=18)
plt.tick_params(axis='y', labelsize=18)
plt.legend(fontsize=18)
plt.tight_layout()
plt.savefig(os.path.join(out_dir, "bucket_time.pdf"))
plt.close()

print("✅ All plots generated in:", out_dir)
"""

with open(out_script, "w") as f:
    f.write(template)

print(f"✅ Static plotting script saved as: {out_script}")

