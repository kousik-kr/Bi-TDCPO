
import matplotlib.pyplot as plt
import os

# Hardcoded experimental results
all_results = [
    {
        "algo": "iSCOPE",
        "dataset": 1070376,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 119.9795,
        "time": 3.9583
    },
    {
        "algo": "iSCOPE",
        "dataset": 1890815,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 123.0736,
        "time": 2.2611
    },
    {
        "algo": "iSCOPE",
        "dataset": 23947347,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 28.2222,
        "time": 2.2492
    },
    {
        "algo": "iSCOPE",
        "dataset": 264346,
        "density": 10,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 65.0282,
        "time": 2.5479
    },
    {
        "algo": "iSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 20.0,
        "cores": 24,
        "interval": 360.0,
        "score": 114.18,
        "time": 2.6064
    },
    {
        "algo": "iSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 16,
        "interval": 360.0,
        "score": 104.1158,
        "time": 2.4312
    },
    {
        "algo": "iSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 1,
        "interval": 360.0,
        "score": 136.969,
        "time": 3.8
    },
    {
        "algo": "iSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 240.0,
        "score": 104.1376,
        "time": 2.1966
    },
    {
        "algo": "iSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 167.7277,
        "time": 4.2655
    },
    {
        "algo": "iSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 480.0,
        "score": 104.3391,
        "time": 2.412
    },
    {
        "algo": "iSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 600.0,
        "score": 50.6934,
        "time": 1.4428
    },
    {
        "algo": "iSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 720.0,
        "score": 47.504,
        "time": 3.5687
    },
    {
        "algo": "iSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 2,
        "interval": 360.0,
        "score": 148.5032,
        "time": 3.7969
    },
    {
        "algo": "iSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 4,
        "interval": 360.0,
        "score": 158.6735,
        "time": 4.0755
    },
    {
        "algo": "iSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 8,
        "interval": 360.0,
        "score": 163.9006,
        "time": 4.3982
    },
    {
        "algo": "iSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 40.0,
        "cores": 24,
        "interval": 360.0,
        "score": 70.4062,
        "time": 1.0646
    },
    {
        "algo": "iSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 50.0,
        "cores": 24,
        "interval": 360.0,
        "score": 201.444,
        "time": 4.0826
    },
    {
        "algo": "iSCOPE",
        "dataset": 264346,
        "density": 30,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 139.8588,
        "time": 2.4402
    },
    {
        "algo": "BiSCOPE",
        "dataset": 1070376,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 172.4852,
        "time": 1.5042
    },
    {
        "algo": "BiSCOPE",
        "dataset": 1890815,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 150.6909,
        "time": 1.1864
    },
    {
        "algo": "BiSCOPE",
        "dataset": 23947347,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 137.0844,
        "time": 1.066
    },
    {
        "algo": "BiSCOPE",
        "dataset": 264346,
        "density": 10,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 110.221,
        "time": 1.6625
    },
    {
        "algo": "BiSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 20.0,
        "cores": 24,
        "interval": 360.0,
        "score": 170.1292,
        "time": 1.5854
    },
    {
        "algo": "BiSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 16,
        "interval": 360.0,
        "score": 176.6748,
        "time": 1.677
    },
    {
        "algo": "BiSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 1,
        "interval": 360.0,
        "score": 109.0927,
        "time": 0.5278
    },
    {
        "algo": "BiSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 240.0,
        "score": 175.9313,
        "time": 1.7167
    },
    {
        "algo": "BiSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 176.7758,
        "time": 1.7076
    },
    {
        "algo": "BiSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 480.0,
        "score": 179.7381,
        "time": 1.6807
    },
    {
        "algo": "BiSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 600.0,
        "score": 164.6783,
        "time": 1.831
    },
    {
        "algo": "BiSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 720.0,
        "score": 169.4194,
        "time": 1.7189
    },
    {
        "algo": "BiSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 2,
        "interval": 360.0,
        "score": 146.5746,
        "time": 1.389
    },
    {
        "algo": "BiSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 4,
        "interval": 360.0,
        "score": 159.7229,
        "time": 1.5155
    },
    {
        "algo": "BiSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 8,
        "interval": 360.0,
        "score": 171.6847,
        "time": 1.6332
    },
    {
        "algo": "BiSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 40.0,
        "cores": 24,
        "interval": 360.0,
        "score": 183.7319,
        "time": 1.7581
    },
    {
        "algo": "BiSCOPE",
        "dataset": 264346,
        "density": 20,
        "overhead": 50.0,
        "cores": 24,
        "interval": 360.0,
        "score": 191.7322,
        "time": 1.8486
    },
    {
        "algo": "BiSCOPE",
        "dataset": 264346,
        "density": 30,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 239.9035,
        "time": 1.6964
    },
    {
        "algo": "TD-A*",
        "dataset": 1070376,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 1.543,
        "time": 0.0011
    },
    {
        "algo": "TD-A*",
        "dataset": 1890815,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 1.417,
        "time": 0.0014
    },
    {
        "algo": "TD-A*",
        "dataset": 23947347,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 1.2207,
        "time": 0.0011
    },
    {
        "algo": "TD-A*",
        "dataset": 264346,
        "density": 10,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 0.8098,
        "time": 0.002
    },
    {
        "algo": "TD-A*",
        "dataset": 264346,
        "density": 20,
        "overhead": 20.0,
        "cores": 24,
        "interval": 360.0,
        "score": 1.3704,
        "time": 0.0018
    },
    {
        "algo": "TD-A*",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 16,
        "interval": 360.0,
        "score": 1.3704,
        "time": 0.0021
    },
    {
        "algo": "TD-A*",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 1,
        "interval": 360.0,
        "score": 1.3704,
        "time": 0.0019
    },
    {
        "algo": "TD-A*",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 240.0,
        "score": 1.3704,
        "time": 0.0018
    },
    {
        "algo": "TD-A*",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 1.3704,
        "time": 0.0019
    },
    {
        "algo": "TD-A*",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 480.0,
        "score": 1.3704,
        "time": 0.002
    },
    {
        "algo": "TD-A*",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 600.0,
        "score": 1.3704,
        "time": 0.002
    },
    {
        "algo": "TD-A*",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 24,
        "interval": 720.0,
        "score": 1.3704,
        "time": 0.0017
    },
    {
        "algo": "TD-A*",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 2,
        "interval": 360.0,
        "score": 1.3704,
        "time": 0.0019
    },
    {
        "algo": "TD-A*",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 4,
        "interval": 360.0,
        "score": 1.3704,
        "time": 0.0019
    },
    {
        "algo": "TD-A*",
        "dataset": 264346,
        "density": 20,
        "overhead": 30.0,
        "cores": 8,
        "interval": 360.0,
        "score": 1.3704,
        "time": 0.002
    },
    {
        "algo": "TD-A*",
        "dataset": 264346,
        "density": 20,
        "overhead": 40.0,
        "cores": 24,
        "interval": 360.0,
        "score": 1.3704,
        "time": 0.0022
    },
    {
        "algo": "TD-A*",
        "dataset": 264346,
        "density": 20,
        "overhead": 50.0,
        "cores": 24,
        "interval": 360.0,
        "score": 1.3704,
        "time": 0.002
    },
    {
        "algo": "TD-A*",
        "dataset": 264346,
        "density": 30,
        "overhead": 30.0,
        "cores": 24,
        "interval": 360.0,
        "score": 2.1301,
        "time": 0.0019
    }
]

buckets = {
    "iSCOPE": {
        "(0-10)": [
            49.5734,
            0.5656
        ],
        "(10-20)": [
            118.9936,
            3.6813
        ],
        "(20-30)": [
            152.3444,
            4.5432
        ],
        "(30-40)": [
            167.2698,
            4.8701
        ],
        "(40-50)": [
            186.6216,
            5.0088
        ],
        "(50-60)": [
            179.1379,
            4.9487
        ]
    },
    "BiSCOPE": {
        "(0-10)": [
            58.0,
            0.0429
        ],
        "(10-20)": [
            143.4904,
            0.7264
        ],
        "(20-30)": [
            175.6875,
            1.412
        ],
        "(30-40)": [
            163.8462,
            1.6485
        ],
        "(40-50)": [
            270.6667,
            1.354
        ],
        "(50-60)": [
            247.75,
            1.7305
        ]
    },
    "TD-A*": {
        "(0-10)": [
            1.3444,
            0.0003
        ],
        "(10-20)": [
            1.1099,
            0.0006
        ],
        "(20-30)": [
            1.4971,
            0.0014
        ],
        "(30-40)": [
            1.4333,
            0.0023
        ],
        "(40-50)": [
            1.7294,
            0.003
        ],
        "(50-60)": [
            1.0759,
            0.0038
        ]
    }
}

markers = {"iSCOPE": "o", "BiSCOPE": "s", "TD-A*": "^"}
defaults = {"dataset": 264346, "density": 20, "overhead": 30.0, "cores": 24, "interval": 360.0}

def sorted_unique(vals):
    return sorted(set(vals), key=lambda x: float(x))

def plot_var(var, all_results, defaults, out_dir):
    def matches_defaults(r):
        for k,v in defaults.items():
            if k == var:
                continue
            if r[k] != v:
                return False
        return True

    xs = sorted_unique([r[var] for r in all_results if matches_defaults(r)])
    positions = range(len(xs))
    algos = sorted(set(r["algo"] for r in all_results))

    plt.figure(figsize=(7,5))
    for algo in algos:
        ys = []
        for val in xs:
            rec = next((r for r in all_results if r["algo"]==algo and r[var]==val and matches_defaults(r)), None)
            ys.append(rec["score"] if rec else float('nan'))
        plt.plot(positions, ys, marker=markers.get(algo, 'o'),
                 markersize=12, markerfacecolor="none", label=algo)
    plt.xticks(positions, [str(x) for x in xs])
    plt.xlabel(var, fontsize=20)
    plt.ylabel("average score", fontsize=20)
    plt.tick_params(axis='x', labelsize=18)
    plt.tick_params(axis='y', labelsize=18)
    plt.legend(fontsize=18)
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, f"compare_{var}_score.pdf"))
    plt.close()

    plt.figure(figsize=(7,5))
    for algo in algos:
        ys = []
        for val in xs:
            rec = next((r for r in all_results if r["algo"]==algo and r[var]==val and matches_defaults(r)), None)
            ys.append(rec["time"] if rec else float('nan'))
        plt.plot(positions, ys, marker=markers.get(algo, 'o'),
                 markersize=12, markerfacecolor="none", label=algo)
    plt.xticks(positions, [str(x) for x in xs])
    plt.xlabel(var, fontsize=20)
    plt.ylabel("average runtime\n(in seconds)", fontsize=20)
    plt.tick_params(axis='x', labelsize=18)
    plt.tick_params(axis='y', labelsize=18)
    plt.legend(fontsize=18)
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, f"compare_{var}_time.pdf"))
    plt.close()


out_dir = os.getcwd()
for var in ["overhead", "density", "cores", "interval", "dataset"]:
    plot_var(var, all_results, defaults, out_dir)

labels = list(next(iter(buckets.values())).keys())
x = range(len(labels))

plt.figure(figsize=(8,5))
for algo, vals in buckets.items():
    scores = [vals[k][0] for k in labels]
    plt.plot(x, scores, marker=markers.get(algo,'o'),
             markersize=12, markerfacecolor="none", label=algo)
plt.xticks(x, labels)
plt.xlabel("fastest path range in minutes", fontsize=20)
plt.ylabel("average score", fontsize=20)
plt.tick_params(axis='x', labelsize=18)
plt.tick_params(axis='y', labelsize=18)
plt.legend(fontsize=18)
plt.tight_layout()
plt.savefig(os.path.join(out_dir, "bucket_score.pdf"))
plt.close()

plt.figure(figsize=(8,5))
for algo, vals in buckets.items():
    times = [vals[k][1] for k in labels]
    plt.plot(x, times, marker=markers.get(algo,'o'),
             markersize=12, markerfacecolor="none", label=algo)
plt.xticks(x, labels)
plt.xlabel("fastest path range in minutes", fontsize=20)
plt.ylabel("average runtime\n(in seconds)", fontsize=20)
plt.tick_params(axis='x', labelsize=18)
plt.tick_params(axis='y', labelsize=18)
plt.legend(fontsize=18)
plt.tight_layout()
plt.savefig(os.path.join(out_dir, "bucket_time.pdf"))
plt.close()

print("✅ All plots generated in:", out_dir)
