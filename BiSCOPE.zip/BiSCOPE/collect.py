import os

# Root folder containing multiple directories
root_folder = "/home/gunturi/eclipse-workspace/JobWWW/"   # change to your root folder

# Define budget bins and labels
bins = [(0, 10), (10, 20), (20, 30), (30, 40), (40, 50), (50, 60)]

# Traverse each subdirectory
for dir_name in sorted(os.listdir(root_folder)):   # also alphabetically sort directories
    dir_path = os.path.join(root_folder, dir_name)
    if not os.path.isdir(dir_path):
        continue  # skip files at root level

    # Output file for this directory
    output_file = os.path.join(root_folder, f"results_{dir_name}.txt")

    with open(output_file, "w") as out:
        # 🔹 Sort file names alphabetically & only take those starting with "Output_"
        for file_name in sorted(os.listdir(dir_path)):
            if not (file_name.startswith("Output_") and file_name.endswith(".txt")):
                continue

            file_path = os.path.join(dir_path, file_name)

            # Data structure for bin stats
            stats = {f"({low}-{high})": {"score_sum": 0.0, "time_sum": 0.0, "count": 0}
                     for low, high in bins}

            total_score, total_time, total_count = 0.0, 0.0, 0

            # Process file
            with open(file_path, "r") as f:
                for line in f:
                    if not line.strip():
                        continue
                    parts = line.split()
                    try:
                        budget = float(parts[3])  # 4th column
                        score = float(parts[5])   # 6th column
                        time  = float(parts[6])   # 7th column
                    except (ValueError, IndexError):
                        continue  # skip bad lines

                    # Place into bin
                    for low, high in bins:
                        if budget > low and budget <= high:
                            label = f"({low}-{high})"
                            stats[label]["score_sum"] += score
                            stats[label]["time_sum"] += time
                            stats[label]["count"] += 1
                            break

                    # Totals
                    total_score += score
                    total_time += time
                    total_count += 1

            # Write results for this file
            out.write(f"\n=== Results for {file_name} ===\n")
            out.write(f"{'Range':<10} {'Avg Score':>12} {'Avg Time':>12} {'Count':>8}\n")
            for low, high in bins:
                label = f"({low}-{high})"
                count = stats[label]["count"]
                if count > 0:
                    avg_score = stats[label]["score_sum"] / count
                    avg_time  = stats[label]["time_sum"] / count
                else:
                    avg_score, avg_time = 0, 0
                out.write(f"{label:<10} {avg_score:12.4f} {avg_time:12.4f} {count:8d}\n")

            # Totals for this file
            if total_count > 0:
                total_avg_score = total_score / total_count
                total_avg_time  = total_time / total_count
            else:
                total_avg_score, total_avg_time = 0, 0

            out.write(f"\nTotal Avg Score: {total_avg_score:.4f}, "
                      f"Total Avg Time: {total_avg_time:.4f}, "
                      f"Total Count: {total_count}\n")
            out.write("="*50 + "\n")

    print(f"✅ Finished processing directory: {dir_name}, results in {output_file}")

