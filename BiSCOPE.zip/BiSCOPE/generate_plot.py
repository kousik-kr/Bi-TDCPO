import re
import os
import matplotlib.pyplot as plt

# ======================
# 1. Parse total averages
# ======================
def parse_results(file_path, algo_name):
    with open(file_path, "r") as f:
        content = f.read()

    pattern = r"=== Results for (Output_[^\n]+)\s+===\n(.*?)(?:\n=+|\Z)"
    matches = re.findall(pattern, content, re.S)

    results = []
    for header, body in matches:
        m = re.match(
            r"Output_[A-Za-z]+_(\d+)_(\d+)_(\d+(?:\.\d+)?)_(\d+)_(\d+(?:\.\d+))\.txt",
            header.strip()
        )
        if not m:
            continue

        dataset, density, overhead, cores, interval = m.groups()
        dataset = int(dataset)
        density = int(density)
        overhead = float(overhead)
        cores = int(cores)
        interval = float(interval)

        # Find total avg line
        m2 = re.search(r"Total Avg Score:\s*([\d.]+),\s*Total Avg Time:\s*([\d.]+)", body)
        if not m2:
            continue
        score, time = map(float, m2.groups())

        results.append({
            "algo": algo_name,
            "dataset": dataset,
            "density": density,
            "overhead": overhead,
            "cores": cores,
            "interval": interval,
            "score": score,
            "time": time,
        })
    return results


# ======================
# 2. Load both algorithms
# ======================
file_i = "results_iSCOPE.txt"
file_b = "results_BiSCOPE.txt"
file_a = "results_Astar.txt"

iSCOPE = parse_results(file_i, "iSCOPE")
BiSCOPE = parse_results(file_b, "BiSCOPE")
Astar = parse_results(file_a, "TD-A*")
all_results = iSCOPE + BiSCOPE + Astar

# Default experimental settings
defaults = {"dataset": 264346, "density": 20, "overhead": 30.0, "cores": 24, "interval": 360.0}

# Define markers for each algorithm
markers = {
    "iSCOPE": "o",     # circle
    "BiSCOPE": "s",     # square
    "TD-A*": "^"     # up arrow
}

# ======================
# 3. Helper for plots
# ======================
def sorted_unique(vals):
    return sorted(set(vals), key=lambda x: float(x))

def plot_var(var, all_results, defaults, out_dir):
    # get x values (the ones that vary)
    def matches_defaults(r):
        for k,v in defaults.items():
            if k == var:
                continue
            if r[k] != v:
                return False
        return True

    xs = sorted_unique([r[var] for r in all_results if matches_defaults(r)])
    positions = range(len(xs))
    algos = sorted(set(r["algo"] for r in all_results))

    # --- Score plot ---
    plt.figure(figsize=(7,5))
    for algo in algos:
        ys = []
        for val in xs:
            rec = next((r for r in all_results if r["algo"]==algo and r[var]==val and matches_defaults(r)), None)
            ys.append(rec["score"] if rec else float('nan'))
        plt.plot(positions, ys, marker=markers.get(algo, 'o'), markersize=12, markerfacecolor="none", label=algo)
    plt.xticks(positions, [str(x) for x in xs])
    plt.xlabel(var, fontsize=20)
    plt.ylabel("average score", fontsize=20)
    plt.tick_params(axis='x', labelsize=18)  # xtick size
    plt.tick_params(axis='y', labelsize=18)  # ytick size
    #plt.title(f"Varying {var} — Score")
    #plt.grid(True)
    plt.legend(fontsize=18)
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, f"compare_{var}_score.pdf"))
    plt.close()

    # --- Time plot ---
    plt.figure(figsize=(7,5))
    for algo in algos:
        ys = []
        for val in xs:
            rec = next((r for r in all_results if r["algo"]==algo and r[var]==val and matches_defaults(r)), None)
            ys.append(rec["time"] if rec else float('nan'))
        plt.plot(positions, ys, marker=markers.get(algo, 'o'), markersize=12, markerfacecolor="none", label=algo)
    plt.xticks(positions, [str(x) for x in xs])
    plt.xlabel(var, fontsize=20)
    plt.ylabel("average runtime\n(in seconds)", fontsize=20)
    plt.tick_params(axis='x', labelsize=18)  # xtick size
    plt.tick_params(axis='y', labelsize=18)  # ytick size
    #plt.title(f"Varying {var} — Time")
    #plt.grid(True)
    plt.legend(fontsize=18)
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, f"compare_{var}_time.pdf"))
    plt.close()


# ======================
# 4. Generate comparisons
# ======================
out_dir = os.path.dirname(os.path.abspath(file_i))  # save in same folder

for var in ["overhead", "density", "cores", "interval", "dataset"]:
    plot_var(var, all_results, defaults, out_dir)


# ======================
# 5. Bucket-wise comparisons (default case)
# ======================
def parse_buckets(file_path, header_key):
    with open(file_path,"r") as f:
        content = f.read()
    pattern = r"=== Results for " + re.escape(header_key) + r".*?===\n(.*?)Total Avg"
    m = re.search(pattern, content, re.S)
    buckets = {}
    if not m:
        return buckets
    section = m.group(1)
    for line in section.splitlines():
        if line.startswith("("):
            parts = line.split()
            rng, score, time = parts[0], float(parts[1]), float(parts[2])
            buckets[rng] = (score, time)
    return buckets

header_i = "Output_iSCOPE_264346_20_30.0_1_360.0.txt"
header_b = "Output_BiSCOPE_264346_20_30.0_1_360.0.txt"
header_a = "Output_Astar_264346_20_30.0_1_360.0.txt"

b_i = parse_buckets(file_i, header_i)
b_b = parse_buckets(file_b, header_b)
b_a = parse_buckets(file_a, header_a)

labels = list(b_i.keys())
scores_a = [b_a[k][0] for k in labels]
scores_i = [b_i[k][0] for k in labels]
scores_b = [b_b[k][0] for k in labels]
times_a = [b_a[k][1] for k in labels]
times_i = [b_i[k][1] for k in labels]
times_b = [b_b[k][1] for k in labels]
x = range(len(labels))

# Score plot
plt.figure(figsize=(8,5))
plt.plot(x, scores_a, marker='^', markersize=12, markerfacecolor="none", label="TD-A*")
plt.plot(x, scores_b, marker='s', markersize=12, markerfacecolor="none", label="BiSCOPE")
plt.plot(x, scores_i, marker='o', markersize=12, markerfacecolor="none", label="iSCOPE")
plt.xticks(x, labels)
plt.xlabel("fastest path range in minutes", fontsize=20)
plt.ylabel("average score", fontsize=20)
plt.tick_params(axis='x', labelsize=18)  # xtick size
plt.tick_params(axis='y', labelsize=18)  # ytick size
#plt.title("Bucket-wise Avg Score Comparison (Default Params)")
#plt.grid(True)
plt.legend(fontsize=18)
plt.tight_layout()
plt.savefig(os.path.join(out_dir, "bucket_score.pdf"))
plt.close()

# Time plot
plt.figure(figsize=(8,5))
plt.plot(x, times_a, marker='^', markersize=12, markerfacecolor="none", label="TD-A*")
plt.plot(x, times_b, marker='s', markersize=12, markerfacecolor="none", label="BiSCOPE")
plt.plot(x, times_i, marker='o', markersize=12, markerfacecolor="none", label="iSCOPE")
plt.xticks(x, labels)
plt.xlabel("fastest path range in minutes", fontsize=20)
plt.ylabel("average runtime\n(in seconds)", fontsize=20)
plt.tick_params(axis='x', labelsize=18)  # xtick size
plt.tick_params(axis='y', labelsize=18)  # ytick size
#plt.title("Bucket-wise Avg Time Comparison (Default Params)")
#plt.grid(True)
plt.legend(fontsize=18)
plt.tight_layout()
plt.savefig(os.path.join(out_dir, "bucket_time.pdf"))
plt.close()

print("✅ All plots generated in:", out_dir)

