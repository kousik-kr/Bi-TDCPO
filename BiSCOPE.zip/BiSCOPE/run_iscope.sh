#!/bin/bash
# Get the current working directory
current_directory=$(pwd)

cd iSCOPE/
javac IntervalCPO.java
echo "NY set for iSCOPE running....."
echo "264346 10 30 24 360"
java -Xss1024m -Xmx250g IntervalCPO $current_directory 264346 10 30 24 360
echo "264346 20 30 24 360"
java -Xss1024m -Xmx250g IntervalCPO $current_directory 264346 20 30 24 360
echo "264346 30 30 24 360"
java -Xss1024m -Xmx250g IntervalCPO $current_directory 264346 30 30 24 360
echo "264346 20 20 24 360"
java -Xss1024m -Xmx250g IntervalCPO $current_directory 264346 20 20 24 360
echo "264346 20 40 24 360"
java -Xss1024m -Xmx250g IntervalCPO $current_directory 264346 20 40 24 360
echo "264346 20 50 24 360"
java -Xss1024m -Xmx250g IntervalCPO $current_directory 264346 20 50 24 360
echo "264346 20 30 24 240"
java -Xss1024m -Xmx250g IntervalCPO $current_directory 264346 20 30 24 240
echo "264346 20 30 24 480"
java -Xss1024m -Xmx250g IntervalCPO $current_directory 264346 20 30 24 480
echo "264346 20 30 24 600"
java -Xss1024m -Xmx250g IntervalCPO $current_directory 264346 20 30 24 600
echo "264346 20 30 24 720"
java -Xss1024m -Xmx250g IntervalCPO $current_directory 264346 20 30 24 720
echo "264346 20 30 2 360"
java -Xss1024m -Xmx250g IntervalCPO $current_directory 264346 20 30 2 360
echo "264346 20 30 4 360"
java -Xss1024m -Xmx250g IntervalCPO $current_directory 264346 20 30 4 360
echo "264346 20 30 8 360"
java -Xss1024m -Xmx250g IntervalCPO $current_directory 264346 20 30 8 360
echo "264346 20 30 16 360"
java -Xss1024m -Xmx250g IntervalCPO $current_directory 264346 20 30 16 360
echo "264346 20 30 1 360"
java -Xss1024m -Xmx250g IntervalCPO $current_directory 264346 20 30 1 360

echo "FLA set for iSCOPE running....."
java -Xss1024m -Xmx250g IntervalCPO $current_directory 1070376 20 30 24 360
echo "CAL set for iSCOPE running....."
java -Xss1024m -Xmx250g IntervalCPO $current_directory 1890815 20 30 24 360
echo "USA set for iSCOPE running....."
java -Xss1024m -Xmx250g IntervalCPO $current_directory 23947347 20 30 24 360
cd ..

cd BiSCOPE/
javac *.java
echo "NY set for BiSCOPE running....."
echo "264346 10 30 24 360"
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 264346 10 30 24 360
echo "264346 20 30 24 360"
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 264346 20 30 24 360
echo "264346 30 30 24 360"
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 264346 30 30 24 360
echo "264346 20 20 24 360"
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 264346 20 20 24 360
echo "264346 20 40 24 360"
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 264346 20 40 24 360
echo "264346 20 50 24 360"
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 264346 20 50 24 360
echo "264346 20 30 24 240"
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 264346 20 30 24 240
echo "264346 20 30 24 480"
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 264346 20 30 24 480
echo "264346 20 30 24 600"
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 264346 20 30 24 600
echo "264346 20 30 24 720"
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 264346 20 30 24 720
echo "264346 20 30 2 360"
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 264346 20 30 2 360
echo "264346 20 30 4 360"
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 264346 20 30 4 360
echo "264346 20 30 8 360"
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 264346 20 30 8 360
echo "264346 20 30 16 360"
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 264346 20 30 16 360
echo "264346 20 30 1 360"
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 264346 20 30 1 360

echo "FLA set for BiSCOPE running....."
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 1070376 20 30 24 360
echo "CAL set for BiSCOPE running....."
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 1890815 20 30 24 360
echo "USA set for BiSCOPE running....."
java -Xss1024m -Xmx250g BidirectionalAstar $current_directory 23947347 20 30 24 360
cd ..

echo "Collecting Results"
python3 collect.py
chmod +x collection.sh
./collection.sh
exit
